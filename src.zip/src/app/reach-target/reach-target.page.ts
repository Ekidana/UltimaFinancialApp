import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';


import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../shared/services/auth.service';
import { User } from '../shared/models/users';
import * as firebase from 'firebase/app';
import 'firebase/firestore';
import { Information } from '../shared/models/information';
import { ModalController, ToastController } from '@ionic/angular';
import { Router } from '@angular/router';


@Component({
  selector: 'app-reach-target',
  templateUrl: './reach-target.page.html',
  styleUrls: ['./reach-target.page.scss'],
})
export class ReachTargetPage {

  user: User = new User();
  haveAccount: string = "no"

  constructor(private authService: AuthService, private modalController: ModalController,public loadingController: LoadingController, private router: Router, private toastController: ToastController) {
    this.user = this.authService.getCurrentUser();
   }

  validation(){
    this.presentLoading();
    setTimeout(()=>{
      
      this.navigate();
  }, 2000);

  }

  async withdraw(){

    let userDoc = firebase.firestore().collection('BankAccount');
    await userDoc.get().then((querySnapshot) => { 
      querySnapshot.forEach((doc) => {
           console.log(doc.id, "=>", doc.data()); 
           if(doc.data().useremail == this.user.email){
            this.haveAccount = "yes"
            this.router.navigate(['/processacc'])
             //alert(doc.data().utID)
            
           } 
           
      })

   })
    if(this.haveAccount=="no"){
      this.router.navigate(['/nonexist-acc'])
    }
   


  }

  async presentLoading() {
    const loading = await this.loadingController.create({
      duration: 2000,
      message: 'Please Wait',
      translucent: true,
    });
    return await loading.present();
  }

  async presentToast() {
    const toast = await this.toastController.create({
      message: 'Money Withdrawed Successfully.',
      duration: 2000
    });
    toast.present();
  }

  navigate(){
    this.router.navigate(['/add-bank'])
  }



}
