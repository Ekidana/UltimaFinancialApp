import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FmsellrequestsPageRoutingModule } from './fmsellrequests-routing.module';

import { FmsellrequestsPage } from './fmsellrequests.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FmsellrequestsPageRoutingModule
  ],
  declarations: [FmsellrequestsPage]
})
export class FmsellrequestsPageModule {}
