import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FmsellrequestsPage } from './fmsellrequests.page';

describe('FmsellrequestsPage', () => {
  let component: FmsellrequestsPage;
  let fixture: ComponentFixture<FmsellrequestsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FmsellrequestsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FmsellrequestsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
