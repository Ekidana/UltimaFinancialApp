import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FmsellrequestsPage } from './fmsellrequests.page';

const routes: Routes = [
  {
    path: '',
    component: FmsellrequestsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FmsellrequestsPageRoutingModule {}
