import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fmsellrequests',
  templateUrl: './fmsellrequests.page.html',
  styleUrls: ['./fmsellrequests.page.scss'],
})
export class FmsellrequestsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
