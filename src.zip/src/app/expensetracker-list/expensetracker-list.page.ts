import { Component, OnInit } from '@angular/core';
import {  SingleExpense } from '../shared/models/singleExpense'; 
import { ExpenseService } from '../shared/services/expense.service'
import { FirebaseExpenseService } from '../shared/services/firebase-expense.service';
import { Expense } from '../shared/models/expense';
import { ExpensetrackerEditPage } from '../expensetracker-edit/expensetracker-edit.page';
import { Router } from '@angular/router';

@Component({
  selector: 'app-expensetracker-list',
  templateUrl: './expensetracker-list.page.html',
  styleUrls: ['./expensetracker-list.page.scss'],
})
export class ExpensetrackerListPage implements OnInit {
expense: Expense[];
expenseId:string; 
private singleExpense: any;
private icons = [ ]
  /*
delete(item:Expense){
  this.expenseService.remove(item).then(() => {

   //refresh list after remove 

    this.expenseService.getAllexpense().then(

      result => this.expense= result
    );
  });
}
**/


  



 public expenses : Array <{ title: string; note: string; icon: string }>
constructor(private expenseService:FirebaseExpenseService , private router: Router){ 


//inserted router:Router in constructor

  // for (let i = 1; i < 50; i++) {
  //   this.expense.push({
  //    // title: "" + this.expense.Id + "" + i,
  //    // note: 'This is expense #' + i,
  //    icons: this.icon[Math.floor(Math.random() * this.icon.length)]
  //   });
  // }
} 
//remove if does not work 
expensetrackeredit(item: Expense){
  this.router.navigateByUrl('/expensetracker-edit/' + item.Id)
} 
 
ngOnInit() {
  this.expenseService.getAllexpense().then(
    result => this.expense = result

    );
  }

}; 
