import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cusverify',
  templateUrl: './cusverify.page.html',
  styleUrls: ['./cusverify.page.scss'],
})
export class CusverifyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
