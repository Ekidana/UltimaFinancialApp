import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as firebase from 'firebase/app';
import 'firebase/firestore';
import { ModalController, ToastController } from '@ionic/angular';
import { Router,ActivatedRoute  } from '@angular/router';
import { Information } from '../shared/models/information';
import { User } from '../shared/models/users';
import { AuthService } from '../shared/services/auth.service';


@Component({
  selector: 'app-confirm-depo',
  templateUrl: './confirm-depo.page.html',
  styleUrls: ['./confirm-depo.page.scss'],
})
export class ConfirmDepoPage implements OnInit {


  deposit: string;
  depositvalue: string;
  depositform: FormGroup;
  user: User = new User();
  utID: any;
  amount: any;

  constructor(private aroute: ActivatedRoute,private authService: AuthService, private modalController: ModalController, private router: Router, private toastController: ToastController) {
    this.user = this.authService.getCurrentUser();

    this.depositform = new FormGroup({
      deposit: new FormControl(this.deposit)
    });

    

    this.aroute.params.subscribe(params => {
          this.deposit = params['deposit']; 
          this.depositform.controls["deposit"].setValue(this.deposit);
          this.depositvalue = this.deposit
        //  alert(this.deposit)
    });

  }

  ngOnInit() {
  }

  async addDeposit() {
    this.deposit = this.depositform.value.deposit
    this.getUTID()


  }

  async getUTID(){
  
    let userDoc = firebase.firestore().collection('UnitTrustAccount');
    userDoc.get().then((querySnapshot) => { 
      querySnapshot.forEach((doc) => {
           console.log(doc.id, "=>", doc.data()); 
           if(doc.data().userEmail == this.user.email){
            this.utID = doc.data().utID
            this.amount = doc.data().utAmount
            alert("hola")
            this.addDepo()
            
           } 
           
      })

      console.log(this.utID)
   })

  }

  async addDepo(){

    var d = Date(); 
    

    const document = firebase.firestore().collection('Deposit').doc();
    const documentid = document.id;
    document.set({
      userEmail: this.user.email,
      depositAmount: this.deposit,
      depositDate: d.toString(),
      depositID:documentid,
      utID: this.utID
    }).then(() => {
      alert("Success")
      this.updateUTAccount()


    });

  }

  async updateUTAccount(){

    var total = parseInt(this.deposit) + parseInt(this.amount)

    firebase.firestore().collection('UnitTrustAccount').doc(this.utID).update({
      utAmount: total.toString()
    }).then(() => {
      alert("Your deposit amount $"+this.deposit+" sucessfully added into your Unit Trust Account.")
      this.router.navigate(['/messagedepo']);
    });

  }


}
