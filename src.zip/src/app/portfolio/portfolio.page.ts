import { Component, OnInit } from '@angular/core';

import { LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AuthService } from '../shared/services/auth.service';
import { FormGroup, FormControl, Validators,ReactiveFormsModule  } from '@angular/forms';
import { ToastController } from '@ionic/angular';
import * as firebase from 'firebase/app';
import  'firebase/firestore';
import { User } from '../shared/models/users';

import { ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.page.html',
  styleUrls: ['./portfolio.page.scss'],
})
export class PortfolioPage implements OnInit {

  user: User = new User();
  fname: any;
  lname: any;
  utName: any;
  utAmount: any;
  interest: any;
  totalAmount: number =0
  totalReturn: number=0

  depositArray: any[] = [];

  constructor(private http: HttpClient,private authService: AuthService,private router: Router,public toastController: ToastController, public loadingController: LoadingController) { 
    this.user = this.authService.getCurrentUser();
    this.getUserDetails()
    this.getUTDetails()


    
  }

  depositChart(){
    this.router.navigate(['/depositchart'])
  }
  withdrawalChart(){
    this.router.navigate(['/withdrawalchart'])
  }


  getUserDetails() {

    let userDoc = firebase.firestore().collection('users');
    userDoc.get().then((querySnapshot) => { 
      querySnapshot.forEach((doc) => {
           console.log(doc.id, "=>", doc.data()); 
           if(doc.data().email == this.user.email){
            // alert(doc.data().accountname)
            this.fname = doc.data().fname
            this.lname = doc.data().lname
           } 
           
      })

      console.log(this.banks)
   })
  }
   

  getUTDetails() {

    let userDoc = firebase.firestore().collection('UnitTrustAccount');
    userDoc.get().then((querySnapshot) => { 
      querySnapshot.forEach((doc) => {
           console.log(doc.id, "=>", doc.data()); 
           if(doc.data().userEmail == this.user.email){
            // alert(doc.data().accountname)
            this.utName = doc.data().utName
            this.utAmount = doc.data().utAmount
            this.interest = doc.data().interest
           } 
           
      })

      this.totalAmount =  parseInt(this.utAmount) + ( parseInt(this.utAmount)* ( parseInt(this.interest)/100 ) )
      this.totalReturn = ( parseInt(this.utAmount)* ( parseInt(this.interest)/100 ) )
    
      console.log(this.banks)
   })
  }
  banks (banks:any) {
    throw new Error("Method not implemented.");
  }

  ngOnInit() {
  }
}