import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddamountPageRoutingModule } from './addamount-routing.module';

import { AddamountPage } from './addamount.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddamountPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AddamountPage]
})
export class AddamountPageModule {}
