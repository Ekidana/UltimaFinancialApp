export class Information {

    photoURL: string;
  
    constructor(  
      public userid?: string,
      public fname?: string,
      public lname?: string,
      public email?: string,
      public nric?: string,
      public role?: string,
      public gender?: string,
      public id? : string
    ) { }
    
  }