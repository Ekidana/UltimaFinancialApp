import { Unittrust } from './unittrust';


export class BuyUnit {
    

    constructor(public unittrust: Unittrust, public quantity: number,public investamount: number) {


    }


}


