import { Component, OnInit } from '@angular/core';
import { File } from '@ionic-native/file/ngx';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import * as firebase from 'firebase';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { ModalController } from '@ionic/angular';
import { AuthService } from '../shared/services/auth.service';
import { User } from '../shared/models/users';

@Component({
  selector: 'app-verifyidentity',
  templateUrl: './verifyidentity.page.html',
  styleUrls: ['./verifyidentity.page.scss'],
})
export class VerifyidentityPage implements OnInit {

  constructor(public camera: Camera, public file: File, private modalController: ModalController, public emailComposer: EmailComposer, private authService: AuthService) { }

  nric: any;
  selfie: any;
  nricimageData: any;
  selfieimageData: any;
  user: User = new User();
  nricboolean: boolean = false;
  selfieboolean: boolean = false;

  ngOnInit() {
    this.user = this.authService.getCurrentUser();
  }

  takenric() {
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      saveToPhotoAlbum: true,
      cameraDirection: 1
    }
    
    this.camera.getPicture().then((imageData) => {
      this.nricimageData = imageData
      let filename = imageData.substring(imageData.lastIndexOf('/') + 1);
      let path = imageData.substring(0, imageData.lastIndexOf('/') + 1);
      this.file.readAsDataURL(path,filename).then((base64data) => {
        this.nric = base64data;
        this.nricboolean = true;
      })
    });     
  }

  takeselfie() {
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      saveToPhotoAlbum: true,
      cameraDirection: 1
    }
    
    this.camera.getPicture().then((imageData) => {
      this.selfieimageData = imageData
      let filename = imageData.substring(imageData.lastIndexOf('/') + 1);
      let path = imageData.substring(0, imageData.lastIndexOf('/') + 1);
      this.file.readAsDataURL(path,filename).then((base64data) => {
        this.selfie = base64data;
        this.selfieboolean = true;
      })
    });     
  }

  submitpicture() {
    if (this.nricboolean === true) {
      if (this.selfieboolean === true){
        firebase.firestore().collection("users").doc(this.user.email).update({
          nricimage: this.nric,
          selfieimage: this.selfie
        }).then(function() {
          console.log("Images successfully added.!");
          alert("You have successfully attempted verification of your identity again. You will receive an email when your identity is confirmed.")
        })
        .catch(function(error) {
          console.error("Error adding Images: ", error);
        });
        this.modalController.dismiss(); 
      }
      else {
        alert("Please ensure that you have taken pictures of the front of your NRIC and your selfie.")
      }
    }
  }
}
