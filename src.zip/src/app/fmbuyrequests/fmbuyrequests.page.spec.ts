import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FmbuyrequestsPage } from './fmbuyrequests.page';

describe('FmbuyrequestsPage', () => {
  let component: FmbuyrequestsPage;
  let fixture: ComponentFixture<FmbuyrequestsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FmbuyrequestsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FmbuyrequestsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
