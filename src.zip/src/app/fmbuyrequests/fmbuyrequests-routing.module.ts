import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FmbuyrequestsPage } from './fmbuyrequests.page';

const routes: Routes = [
  {
    path: '',
    component: FmbuyrequestsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FmbuyrequestsPageRoutingModule {}
