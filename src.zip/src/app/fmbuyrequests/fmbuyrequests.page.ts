import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fmbuyrequests',
  templateUrl: './fmbuyrequests.page.html',
  styleUrls: ['./fmbuyrequests.page.scss'],
})
export class FmbuyrequestsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
