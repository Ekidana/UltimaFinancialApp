export class BuyAmount {
    constructor(private investamount: number, private date: Date) {}
}