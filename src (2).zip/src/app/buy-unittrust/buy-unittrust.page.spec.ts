import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BuyUnittrustPage } from './buy-unittrust.page';

describe('BuyUnittrustPage', () => {
  let component: BuyUnittrustPage;
  let fixture: ComponentFixture<BuyUnittrustPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyUnittrustPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BuyUnittrustPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
