import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellunit',
  templateUrl: './sellunit.page.html',
  styleUrls: ['./sellunit.page.scss'],
})
export class SellunitPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
