export class Unverifiedids {

    photoURL: string;
  
    constructor(  
      public userid?: string,
    ) { }
    
  }