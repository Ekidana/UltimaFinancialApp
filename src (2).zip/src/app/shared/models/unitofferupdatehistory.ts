import { Unittrust } from './unittrust';

export class UnitOfferUpdatehistory {
    constructor(private date: string, private offerprice: number) {}

}