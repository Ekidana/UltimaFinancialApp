import { Unittrust } from './unittrust';

export class UnitCartItem {
    constructor(public unittrust: Unittrust, private quantity: number) {}

}