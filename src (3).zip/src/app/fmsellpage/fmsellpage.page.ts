import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-fmsellpage',
  templateUrl: './fmsellpage.page.html',
  styleUrls: ['./fmsellpage.page.scss'],
})
export class FmsellpagePage implements OnInit {
  investname: string;
  investquantity: number;
  offer_bid_pricesubmitted: string;
  sellForm: FormGroup;
  submitted: boolean;
  constructor(private route: ActivatedRoute) {
    this.sellForm = new FormGroup({
      price: new FormControl('', [Validators.required]),
    });
  }

  ngOnInit() {
    firebase.firestore().collection('fmrequests').doc(this.route.snapshot.params.id).get().then(doc => {
      this.investname = doc.data().investname;
      this.investquantity = doc.data().investquantity;
      this.offer_bid_pricesubmitted = doc.data().offer_bid_pricesubmitted;
    })
  }

  confirm() {
    this.submitted = true;

    if (this.sellForm.valid) {
      if (this.sellForm.value.price >= this.offer_bid_pricesubmitted) {
        alert("Can Sell")
      }
      else {
        alert("Cannot Sell as make loss.")
      }
    }
  }

}
