import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BuyUnittrustPage } from './buy-unittrust.page';

const routes: Routes = [
  {
    path: '',
    component: BuyUnittrustPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BuyUnittrustPageRoutingModule {}
