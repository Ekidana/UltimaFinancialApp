import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BuyUnittrustPageRoutingModule } from './buy-unittrust-routing.module';

import { BuyUnittrustPage } from './buy-unittrust.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    BuyUnittrustPageRoutingModule
  ],
  declarations: [BuyUnittrustPage]
})
export class BuyUnittrustPageModule {}
