import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { BuyUnit } from '../shared/models/buyunit';
import { AddUnittrustPage } from '../add-unittrust/add-unittrust.page';
import * as firebase from 'firebase/app';
import 'firebase/firestore';
import { Unittrust } from '../shared/models/unittrust';
import { AuthService } from '../shared/services/auth.service';
import { User } from '../shared/models/users';
import { FirebaseUnittrustService } from '../shared/services/firebase-unittrust.service';
import { BuyunitService } from '../shared/services/buyunit.service';
import { BuyAmount } from '../shared/models/buyAmount';
import { ToastController } from '@ionic/angular';


@Component({
  selector: 'app-buy-unittrust',
  templateUrl: './buy-unittrust.page.html',
  styleUrls: ['./buy-unittrust.page.scss'],
})
export class BuyUnittrustPage implements OnInit {
  buyUnit: BuyUnit[];
  // buyAmountArray: BuyAmount[];




  constructor(private toastController: ToastController, private authService: AuthService,private buyunitService: BuyunitService) {
  }
   

  //  investamount() {
  //     const promise = new Promise<string>((resolve, reject) => {
  //       this.buyunitService.getBuyUnitId().then(buyId => {
          
          
  //       firebase.firestore().collection('buyunittrust/' + buyId + '/buyitem').get().then(doc => {
  //         if (doc.empty) {
  //           console.log ('empty')
  //         }
  //         else {
  //           this.buyAmountArray = [];
  //           doc.forEach(invest =>{
  //             const i = new BuyAmount(invest.data().investamount, invest.data().date)
  //             this.buyAmountArray.push(i)
  //           });
  //         }


  //         }).catch(err => {
  //           console.log('error document' ,err);
  //         });
  //       })
  //       return promise
  //     })
  //   }
    


    async checkout() {
      this.buyunitService.checkout().then(() => {

    // Refresh the cart after check out
    this.buyunitService.getBuyunitItems().then(

      result =>  this.buyUnit = result

    );

  });

  const toast = await this.toastController.create({
    message: 'The amount of the unittrust will be charge towards your deposit account',
    duration: 2000,
    position: 'top',
    color: 'secondary'
  });
  toast.present();
}

        
    
      
    



  ngOnInit() {
    this.buyunitService.getBuyunitItems().then(

      result =>  this.buyUnit = result

    );
  }



  


}
