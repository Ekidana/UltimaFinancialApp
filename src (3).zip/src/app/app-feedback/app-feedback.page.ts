import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-feedback',
  templateUrl: './app-feedback.page.html',
  styleUrls: ['./app-feedback.page.scss'],
})
export class AppFeedbackPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
