import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listacc',
  templateUrl: './listacc.page.html',
  styleUrls: ['./listacc.page.scss'],
})
export class ListaccPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
